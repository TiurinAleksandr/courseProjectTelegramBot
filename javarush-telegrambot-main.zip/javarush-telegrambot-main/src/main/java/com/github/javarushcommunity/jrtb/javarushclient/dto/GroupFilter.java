package com.github.javarushcommunity.jrtb.javarushclient.dto;

/**
 * Filters for group requests.
 */
public enum GroupFilter {

    UNKNOWN, MY, ALL
}
