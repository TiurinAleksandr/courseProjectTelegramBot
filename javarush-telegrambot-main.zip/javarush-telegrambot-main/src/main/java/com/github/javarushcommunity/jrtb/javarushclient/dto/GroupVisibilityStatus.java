package com.github.javarushcommunity.jrtb.javarushclient.dto;

/**
 * Group Visibility status.
 */
public enum GroupVisibilityStatus {
    UNKNOWN, RESTRICTED, PUBLIC, PROTECTED, PRIVATE, DISABLED, DELETED
}
