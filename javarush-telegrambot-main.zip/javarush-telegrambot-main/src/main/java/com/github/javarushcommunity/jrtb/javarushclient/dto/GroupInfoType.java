package com.github.javarushcommunity.jrtb.javarushclient.dto;

/**
 * Group Info type;
 */
public enum GroupInfoType {
    UNKNOWN, CITY, COMPANY, COLLEGE, TECH, SPECIAL, COUNTRY
}
