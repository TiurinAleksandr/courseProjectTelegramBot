package com.github.javarushcommunity.jrtb.javarushclient.dto;

/**
 * DTO, which represents like's information.
 */
public class LikesInfo {

    private Integer count;
    private LikeStatus status;
}
