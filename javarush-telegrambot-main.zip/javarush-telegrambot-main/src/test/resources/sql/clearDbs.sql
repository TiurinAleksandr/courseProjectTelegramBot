DELETE FROM group_x_user;
DELETE FROM group_sub;
DELETE FROM tg_user;
